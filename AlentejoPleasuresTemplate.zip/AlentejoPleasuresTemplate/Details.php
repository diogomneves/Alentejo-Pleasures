<!doctype html>
<html lang="pt">
<head>
    <title>Alentejo Pleasures</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <link rel="stylesheet" href="fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/magnific-popup.css">


    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/jquery-migrate-3.0.0.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>

    <script src="js/jquery.magnific-popup.min.js"></script>

    <script src="js/main.js"></script>

    <!-- Theme Style -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="block-45">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <ul class="block-45-list">




                    <!-- VER SE ESTÀ LOGADO -->
                    <?php

                    include_once "QuerysUser.php";

                    session_start();

                    $nuser = new QuerysUser("", "", "");
                    $result = $nuser->check_session();

                    if ($result) {
                        echo $_SESSION['username'];
                        echo "<li><a></a></li>";
                        echo "<li><a href=\"php/logout.php\">Logout</a></li>";


                    }

                    else{

                        echo " <li><a href=\"Login.php\">Login</a></li>";
                        echo "<li><a href=\"Register.php\">Registar</a></li>";
                    }

                    ?>
                </ul>



            </div>
            <div class="col-md-6 text-md-right">
                <ul class="block-45-icons">
                    <li><a href="3"><span class="fa fa-facebook"></span></a></li>
                    <li><a href="3"><span class="fa fa-twitter"></span></a></li>
                    <li><a href="3"><span class="fa fa-linkedin"></span></a></li>
                    <li><a href="3"><span class="fa fa-instagram"></span></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>


<header role="banner">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand absolute" href="index.php">Alentejo Pleasures</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample05" aria-controls="navbarsExample05" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse navbar-light" id="navbarsExample05">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Hotels.php">Hóteis</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Monuments.php">Monumentos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Restaurants.php">Restaurantes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Adega.php">Vinhos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Praias.php">Praias</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Route.php">Rotas</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Experiences.php">Experiências</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="" id="dropdown05" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Sobre Nós</a>
                        <div class="dropdown-menu" aria-labelledby="dropdown05">
                            <a class="dropdown-item" href="Contact.php">Contactos</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
<!-- END header -->

</div>



<div style="background-color: white">
    <table>
        <tr><td style="font-family: Small caps; font-size: 30px" id="name1" align="center"></td></tr>
        <tr><td style="font-family: Small caps; padding: 25px" id="address" align="center"></td></tr>
        <tr><td style="padding: 25px;" id="image1"></td>
            <td style="padding: 25px" id="description1"></td></tr>
    </table>

    <div id="divComment">
        <p id="comment"></p>

    </div>


    <section class="site-section bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-8 pr-md-5">
                    <form action="#" method="post">
                        <div class="row">
                            <div class="col-md-12 form-group">
                                <label for="message">Mensagem</label>
                                <textarea name="message" id="message" class="form-control py-2" cols="30" rows="8"></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 form-group">
                                <input id="button" type="button" value="Enviar" class="btn btn-send btn-primary py-3 px-5">
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-4">

                    <div class="block-23">
                        <h3 class="heading mb-5">Localização:</h3>
                        <ul>
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d99821.96184347881!2d-7.981049614663758!3d38.56979933189351!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd19e4df3883139d%3A0xa6ad8a31c3bdef6c!2zw4l2b3Jh!5e0!3m2!1spt-PT!2spt!4v1544186119159" width="450" height="270" frameborder="2" style="border:0;" allowfullscreen></iframe>

                        </ul>
                    </div>
                </div>

            </div>

        </div>
    </section>
    <!-- END section -->


</div>




<footer class="site-footer">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-6 col-lg-3 mb-5 mb-lg-0">
                <h3 class="heading">Contactos</h3>
                <div class="block-23 float-md-right">
                    <ul>
                        <li><span class="icon ion-android-pin"></span><span class="text">Rua Coronel Manuel Emidio Lt.4 - Évora</span></li>
                        <li><a href="#"><span class="icon ion-ios-telephone"></span><span class="text">266 754 890</span></a></li>
                        <li><a href="#"><span class="icon ion-android-mail"></span><span class="text">alentejopleasures@gmail.com</span></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="row pt-5">
            <div class="col-md-12 text-center copyright">

                <p class="float-md-left"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Alentejo Pleasures
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                <p class="float-md-right">
                    <a href="#" class="fa fa-facebook p-2"></a>
                    <a href="#" class="fa fa-twitter p-2"></a>
                    <a href="#" class="fa fa-linkedin p-2"></a>
                    <a href="#" class="fa fa-instagram p-2"></a>

                </p>
            </div>
        </div>
    </div>
</footer>
<!-- END footer -->




<script>


    var url = window.location.search.split("=");
    var id = url[1];


    $.post(
        "php/getTablePost_id.php",
        {
            local_id : id
        },
        function(data, status){
            if (status == "success")
            {
                var objData = JSON.parse(data);
                // var aux = objData[0].name + "<br><br>" + objData[0].address;
                $("td#description1").html(objData[0].description);
                $("td#name1").html(objData[0].name);
                $("td#address").html(objData[0].address);
                $("td#image1").html("<img src='" + objData[0].image + "' alt=''  height='300'>");
                //    $("td#name1").html(aux);



            }
        }
    );

    $("input#button").click(function () {

        var comment = $("textarea#message").val();
        var username = $("ul#username").text().trim();

        alert(username);
        var user_id = "";

        $.post(
            "php/get_userId.php",
            {
                username : username
            },
            function(data, status){
                if (status == "success")
                {
                    var objData = JSON.parse(data);
                    user_id = objData.user_id;

                }
            }
        );

        alert(user_id);



        $.post(
            "php/insertComment.php",
            {
                local_id : id,
                comment : comment,
                user_id : user_id

            },
            function(data, status){
                if (status == "success")
                {

                    $("p#comment").text(comment);
                }
            }
        )
    });



</script>



</body>
</html>








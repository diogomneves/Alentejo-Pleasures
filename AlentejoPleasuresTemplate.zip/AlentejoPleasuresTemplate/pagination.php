<?php
//pagination.php
$connect = mysqli_connect("localhost", "twdm", "password", "alentejopleasures");
$connect-> set_charset('utf8mb4');
$record_per_page = 5;
$page = '';
$output = '';
if(isset($_POST["page"]))
{
    $page = $_POST["page"];
}
else
{
    $page = 1;
}
$start_from = ($page - 1)*$record_per_page;
$query = "SELECT * FROM local ORDER BY local_id DESC LIMIT $start_from, $record_per_page";
$result = mysqli_query($connect, $query);
$output .= "  
  
  <table class='table table-bordered' style='align=center; border=4; cellspacing=10; cellpadding=4; height: 10% '> 
           <tr>  
                <th width='50%'>Name</th>   
                <th width='50%'>Image</th>
           </tr>";

while($row = mysqli_fetch_array($result))
{
    $output .= '  
           <tr>  
                <td>'.$row["name"].'</td>
                </tr>
                <td ><img  src="' . $row['image'] .'" height=\'250\' width=\'350\'></td>
                <td>'.$row["description"].'</td>  
           </tr>  
           
      
           
           
           
           
      ';
}
$output .= '</table><br /><div align="center">';
$page_query = "SELECT * FROM local ORDER BY local_id DESC";
$page_result = mysqli_query($connect, $page_query);
$total_records = mysqli_num_rows($page_result);
$total_pages = ceil($total_records/$record_per_page);
for($i=1; $i<=$total_pages; $i++)
{
    $output .= "<span class='pagination_link' style='cursor:pointer; padding:6px; border:1px solid #ccc;' id='".$i."'>".$i."</span>";
}
$output .= '</div><br /><br />';
echo $output;
?>


<!doctype html>
<html lang="pt">
<head>
    <title>Alentejo Pleasures</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <link rel="stylesheet" href="fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <!-- Theme Style -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="wrap">
    <div class="block-45">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <ul class="block-45-list">
                        <li><a href="login.html">Login</a></li>
                        <li><a href="registo.html">Registar</a></li>
                    </ul>
                </div>
                <div class="col-md-6 text-md-right">
                    <ul class="block-45-icons">
                        <li><a href="3"><span class="fa fa-facebook fa-lg"></span></a></li>
                        <li><a href="3"><span class="fa fa-twitter fa-lg"></span></a></li>
                        <li><a href="3"><span class="fa fa-linkedin fa-lg"></span></a></li>
                        <li><a href="3"><span class="fa fa-instagram fa-lg"></span></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <header role="banner">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand absolute" href="index.html">Alentejo Pleasures</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample05" aria-controls="navbarsExample05" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse navbar-light" id="navbarsExample05">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Início</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Hotels.php">Hóteis</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Monuments.php">Monumentos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Restaurants.php">Restaurantes</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Adega.php">Vinhos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Route.php">Rotas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Experiences.php">Experiências</a>
                        </li>
                        <li class="nav-item dropdown active">
                            <a class="nav-link dropdown-toggle" href="" id="dropdown05" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Sobre Nós</a>
                            <div class="dropdown-menu" aria-labelledby="dropdown05">
                                <a class="dropdown-item active" href="colaboradores.php">Colaboradores</a>
                                <a class="dropdown-item" href="Contact.php">Contactos</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- END header -->

    <section class="site-hero overlay" data-stellar-background-ratio="0.5" style="background-image: url(images/big_image_2.jpg);">
        <div class="container">
            <div class="row align-items-center justify-content-center site-hero-inner">
                <div class="col-md-8 text-center">

                    <div class="mb-5 element-animate">
                        <div class="block-17">

                            <h1 class="heading mb-4">Bible studies like Bereans did</h1>
                            <span class="lead">Posted on June 28, 2018 by Pastor Gregg Smith</span>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- END section -->





    <div class="site-section bg-light">
        <div class="container">
            <div class="row">

                <div class="col-md-6 col-lg-8 order-md-2 pl-lg-5">
                    <div class="row">
                        <div class="col-md-12 col-lg-12 mb-5">

                            <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda nihil aspernatur nemo sunt, qui, harum repudiandae quisquam eaque dolore itaque quod tenetur quo quos labore?</p>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae expedita cumque necessitatibus ducimus debitis totam, quasi praesentium eveniet tempore possimus illo esse, facilis? Corrupti possimus quae ipsa pariatur cumque, accusantium tenetur voluptatibus incidunt reprehenderit, quidem repellat sapiente, id, earum obcaecati.</p>

                            <blockquote><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident vero tempora aliquam excepturi labore, ad soluta voluptate necessitatibus. Nulla error beatae, quam, facilis suscipit quaerat aperiam minima eveniet quis placeat.</p></blockquote>

                            <p>Eveniet deleniti accusantium nulla natus nobis nam asperiores ipsa minima laudantium vero cumque cupiditate ipsum ratione dicta, expedita quae, officiis provident harum nisi! Esse eligendi ab molestias, quod nostrum hic saepe repudiandae non. Suscipit reiciendis tempora ut, saepe temporibus nemo.</p>
                            <p>Accusamus, temporibus, ullam. Voluptate consectetur laborum totam sunt culpa repellat, dolore voluptas. Quaerat cum ducimus aut distinctio sit, facilis corporis ab vel alias, voluptas aliquam, expedita molestias quisquam sequi eligendi nobis ea error omnis consequatur iste deleniti illum, dolorum odit.</p>
                            <p>In adipisci corporis at delectus! Cupiditate, voluptas, in architecto odit id error reprehenderit quam quibusdam excepturi distinctio dicta laborum deserunt qui labore dignissimos necessitatibus reiciendis tenetur corporis quas explicabo exercitationem suscipit. Nisi quo nulla, nihil harum obcaecati vel atque quos.</p>
                            <p>Amet sint explicabo maxime accusantium qui dicta enim quia, nostrum id libero voluptates quae suscipit dolor quam tenetur dolores inventore illo laborum, corporis non ex, debitis quidem obcaecati! Praesentium maiores illo atque error! Earum, et, fugit. Sint, delectus molestiae. Totam.</p>

                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Culpa iste, repudiandae facere aperiam sapiente, officia delectus soluta molestiae nihil corporis animi quos ratione qui labore? Sint eaque perspiciatis minus illum.</p>
                            <p>Consectetur porro odio quod iure quaerat cupiditate similique, dolor reprehenderit molestias provident, esse dolorum omnis architecto magni amet corrupti neque ratione sunt beatae perspiciatis? Iste pariatur omnis sed ut itaque.</p>
                            <p>Id similique, rem ipsam accusantium iusto dolores sit velit ex quas ea atque, molestiae. Sint, sed. Quisquam, suscipit! Quisquam quibusdam maiores fugiat eligendi eius consequuntur, molestiae saepe commodi expedita nemo!</p>
                            <div class="pt-5">
                                <p>Categories:  <a href="#">Design</a>, <a href="#">Events</a>  Tags: <a href="#">#course</a>, <a href="#">#trends</a></p>
                            </div>


                            <div class="pt-5">
                                <h3 class="mb-5">6 Comments</h3>
                                <ul class="comment-list">
                                    <li class="comment">
                                        <div class="vcard bio">
                                            <img src="images/person_1.jpg" alt="Image placeholder">
                                        </div>
                                        <div class="comment-body">
                                            <h3>Jean Doe</h3>
                                            <div class="meta">January 9, 2018 at 2:21pm</div>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur quidem laborum necessitatibus, ipsam impedit vitae autem, eum officia, fugiat saepe enim sapiente iste iure! Quam voluptas earum impedit necessitatibus, nihil?</p>
                                            <p><a href="#" class="reply">Reply</a></p>
                                        </div>
                                    </li>

                                    <li class="comment">
                                        <div class="vcard bio">
                                            <img src="images/person_1.jpg" alt="Image placeholder">
                                        </div>
                                        <div class="comment-body">
                                            <h3>Jean Doe</h3>
                                            <div class="meta">January 9, 2018 at 2:21pm</div>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur quidem laborum necessitatibus, ipsam impedit vitae autem, eum officia, fugiat saepe enim sapiente iste iure! Quam voluptas earum impedit necessitatibus, nihil?</p>
                                            <p><a href="#" class="reply">Reply</a></p>
                                        </div>

                                        <ul class="children">
                                            <li class="comment">
                                                <div class="vcard bio">
                                                    <img src="images/person_1.jpg" alt="Image placeholder">
                                                </div>
                                                <div class="comment-body">
                                                    <h3>Jean Doe</h3>
                                                    <div class="meta">January 9, 2018 at 2:21pm</div>
                                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur quidem laborum necessitatibus, ipsam impedit vitae autem, eum officia, fugiat saepe enim sapiente iste iure! Quam voluptas earum impedit necessitatibus, nihil?</p>
                                                    <p><a href="#" class="reply">Reply</a></p>
                                                </div>


                                                <ul class="children">
                                                    <li class="comment">
                                                        <div class="vcard bio">
                                                            <img src="images/person_1.jpg" alt="Image placeholder">
                                                        </div>
                                                        <div class="comment-body">
                                                            <h3>Jean Doe</h3>
                                                            <div class="meta">January 9, 2018 at 2:21pm</div>
                                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur quidem laborum necessitatibus, ipsam impedit vitae autem, eum officia, fugiat saepe enim sapiente iste iure! Quam voluptas earum impedit necessitatibus, nihil?</p>
                                                            <p><a href="#" class="reply">Reply</a></p>
                                                        </div>

                                                        <ul class="children">
                                                            <li class="comment">
                                                                <div class="vcard bio">
                                                                    <img src="images/person_1.jpg" alt="Image placeholder">
                                                                </div>
                                                                <div class="comment-body">
                                                                    <h3>Jean Doe</h3>
                                                                    <div class="meta">January 9, 2018 at 2:21pm</div>
                                                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur quidem laborum necessitatibus, ipsam impedit vitae autem, eum officia, fugiat saepe enim sapiente iste iure! Quam voluptas earum impedit necessitatibus, nihil?</p>
                                                                    <p><a href="#" class="reply">Reply</a></p>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>

                                    <li class="comment">
                                        <div class="vcard bio">
                                            <img src="images/person_1.jpg" alt="Image placeholder">
                                        </div>
                                        <div class="comment-body">
                                            <h3>Jean Doe</h3>
                                            <div class="meta">January 9, 2018 at 2:21pm</div>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur quidem laborum necessitatibus, ipsam impedit vitae autem, eum officia, fugiat saepe enim sapiente iste iure! Quam voluptas earum impedit necessitatibus, nihil?</p>
                                            <p><a href="#" class="reply">Reply</a></p>
                                        </div>
                                    </li>
                                </ul>
                                <!-- END comment-list -->

                                <div class="comment-form-wrap pt-5">
                                    <h3 class="mb-5">Leave a comment</h3>
                                    <form action="#" class="bg-light">
                                        <div class="form-group">
                                            <label for="name">Name *</label>
                                            <input type="text" class="form-control" id="name">
                                        </div>
                                        <div class="form-group">
                                            <label for="email">Email *</label>
                                            <input type="email" class="form-control" id="email">
                                        </div>
                                        <div class="form-group">
                                            <label for="website">Website</label>
                                            <input type="url" class="form-control" id="website">
                                        </div>

                                        <div class="form-group">
                                            <label for="message">Message</label>
                                            <textarea name="" id="message" cols="30" rows="10" class="form-control"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <input type="submit" value="Post Comment" class="btn btn-primary py-2 px-4">
                                        </div>

                                    </form>
                                </div>
                            </div>

                        </div>
                    </div>


                </div>
                <!-- END content -->
                <div class="col-md-6 col-lg-4 order-md-1">

                    <div class="block-24 mb-5">
                        <h3 class="heading">Categories</h3>
                        <ul>
                            <li><a href="#">Events <span>10</span></a></li>
                            <li><a href="#">Outreach <span>43</span></a></li>
                            <li><a href="#">Baptism <span>21</span></a></li>
                            <li><a href="#">Charity <span>65</span></a></li>
                            <li><a href="#">Donate <span>34</span></a></li>
                            <li><a href="#">Building Fund <span>45</span></a></li>
                            <li><a href="#">Health <span>22</span></a></li>
                        </ul>
                    </div>

                    <div class="block-25 mb-5">
                        <div class="heading">Recent Events</div>
                        <ul>
                            <li>
                                <a href="#" class="d-flex">
                                    <figure class="image mr-3">
                                        <img src="images/img_2_b.jpg" alt="" class="img-fluid">
                                    </figure>
                                    <div class="text">
                                        <h3 class="heading">Soluta voluptate necessitatibus</h3>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="d-flex">
                                    <figure class="image mr-3">
                                        <img src="images/img_2_b.jpg" alt="" class="img-fluid">
                                    </figure>
                                    <div class="text">
                                        <h3 class="heading">Voluptate consectetur laborum totam</h3>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="d-flex">
                                    <figure class="image mr-3">
                                        <img src="images/img_2_b.jpg" alt="" class="img-fluid">
                                    </figure>
                                    <div class="text">
                                        <h3 class="heading">Deserunt qui labore dignissimos </h3>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </div>

                    <div class="block-26">
                        <h3 class="heading">Tags</h3>
                        <ul>
                            <li><a href="#">events</a></li>
                            <li><a href="#">gospel</a></li>
                            <li><a href="#">charity</a></li>
                            <li><a href="#">love</a></li>
                            <li><a href="#">baptism</a></li>
                            <li><a href="#">faith</a></li>
                        </ul>
                    </div>


                </div>
                <!-- END Sidebar -->
            </div>
        </div>
    </div>



    <footer class="site-footer">
        <div class="container">
            <div class="row mb-5">
                <!--   <div class="col-md-6 col-lg-3 mb-5 mb-lg-0">
                    <p>Perferendis eum illum voluptatibus dolore tempora consequatur minus asperiores temporibus.</p>
                  </div> -->
                <!--div class="col-md-6 col-lg-6 mb-5 mb-lg-0">
                  <h3 class="heading">Church Quick Links</h3>
                  <div class="row">
                    <div class="col-md-4">
                      <ul class="list-unstyled">
                        <li><a href="#">Men's Ministry</a></li>
                        <li><a href="#">Women's Ministry</a></li>
                        <li><a href="#">Children's Ministry</a></li>
                        <li><a href="#">Youth Ministry</a></li>
                      </ul>
                    </div>
                    <div class="col-md-4">
                      <ul class="list-unstyled">
                        <li><a href="#">Senior Adult Ministry</a></li>
                        <li><a href="#">Marriage Ministries</a></li>
                        <li><a href="#">Missions & Outreach</a></li>
                        <li><a href="#">Prayer Ministry</a></li>
                      </ul>
                    </div>
                    <div class="col-md-4">
                      <ul class="list-unstyled">
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Location</a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="#">Privacy &amp; Policy</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-lg-3 mb-5 mb-lg-0">
                  <h3 class="heading">Events</h3>
                  <div class="block-21 d-flex mb-4">
                    <div class="text">
                      <h3 class="heading mb-0"><a href="#">Consectetur Adipisicing Elit</a></h3>
                      <div class="meta">
                        <div><a href="#"><span class="ion-android-calendar"></span> May 29, 2018</a></div>
                        <div><a href="#"><span class="ion-android-person"></span> Admin</a></div>
                        <div><a href="#"><span class="ion-chatbubble"></span> 19</a></div>
                      </div>
                    </div>
                  </div>
                  <div class="block-21 d-flex mb-4">
                    <div class="text">
                      <h3 class="heading mb-0"><a href="#">Dolore Tempora Consequatur</a></h3>
                      <div class="meta">
                        <div><a href="#"><span class="ion-android-calendar"></span> May 29, 2018</a></div>
                        <div><a href="#"><span class="ion-android-person"></span> Admin</a></div>
                        <div><a href="#"><span class="ion-chatbubble"></span> 19</a></div>
                      </div>
                    </div>
                  </div>
                  <div class="block-21 d-flex mb-4">
                    <div class="text">
                      <h3 class="heading mb-0"><a href="#">Perferendis eum illum</a></h3>
                      <div class="meta">
                        <div><a href="#"><span class="ion-android-calendar"></span> May 29, 2018</a></div>
                        <div><a href="#"><span class="ion-android-person"></span> Admin</a></div>
                        <div><a href="#"><span class="ion-chatbubble"></span> 19</a></div>
                      </div>
                    </div>
                  </div>
                </div-->
                <div class="col-md-6 col-lg-3 mb-5 mb-lg-0">
                    <h3 class="heading">Contactos</h3>
                    <div class="block-23 float-md-right">
                        <ul>
                            <li><span class="icon ion-android-pin"></span><span class="text">Rua Coronel Manuel Emidio Lt.4 - Évora</span></li>
                            <li><a href="#"><span class="icon ion-ios-telephone"></span><span class="text">266 754 890</span></a></li>
                            <li><a href="#"><span class="icon ion-android-mail"></span><span class="text">alentejopleasures@gmail.com</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row pt-5">
                <div class="col-md-12 text-center copyright">

                    <p class="float-md-left"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Alentejo Pleasures
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                    <p class="float-md-right">
                        <a href="#" class="fa fa-facebook p-2"></a>
                        <a href="#" class="fa fa-twitter p-2"></a>
                        <a href="#" class="fa fa-linkedin p-2"></a>
                        <a href="#" class="fa fa-instagram p-2"></a>

                    </p>
                </div>
            </div>
        </div>
    </footer>
    <!-- END footer -->

</div>

<!-- loader -->
<div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#f4b214"/></svg></div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/jquery-migrate-3.0.0.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>

<script src="js/jquery.magnific-popup.min.js"></script>

<script src="js/main.js"></script>
</body>
</html>
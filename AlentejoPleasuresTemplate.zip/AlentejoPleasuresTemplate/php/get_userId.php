<?php
/**
 * Created by PhpStorm.
 * User: Diogo
 * Date: 23/01/2019
 * Time: 17:18
 */

include_once "db.php";

$conn = connDB();

if(!empty($_POST)) {

    $name = $_POST['username'];
    $result = getUserId($conn, $name);

    $rows = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc())
            array_push($rows, $row);
    }


}

echo json_encode($rows);



?>
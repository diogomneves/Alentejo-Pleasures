<?php
/**
 * Created by PhpStorm.
 * User: ESEB
 * Date: 15-11-2018
 * Time: 12:55
 */

include_once "db.php";

$conn = connDB();
$result = query_districts($conn);

$rows = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc())
        array_push($rows, $row);
}

echo json_encode($rows);

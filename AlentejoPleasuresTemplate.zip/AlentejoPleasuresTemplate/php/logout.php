<?php

include_once "../QuerysUser.php";

session_start();

$nuser = new QuerysUser("", "", "");
$result = $nuser->close_session();

if ($result)
    echo "fechada";
else
    header("Location: index.php");

?>

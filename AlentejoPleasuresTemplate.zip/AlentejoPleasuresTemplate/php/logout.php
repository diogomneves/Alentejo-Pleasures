<?php

include_once "../QuerysUser.php";

session_start();

$nuser = new QuerysUser("", "", "");
$result = $nuser->close_session();

if ($result) {
    header("location: ../index.php");
}
else



?>

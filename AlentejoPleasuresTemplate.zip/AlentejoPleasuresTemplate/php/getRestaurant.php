<?php
/**
 * Created by PhpStorm.
 * User: Diogo
 * Date: 22/01/2019
 * Time: 19:29
 */
include_once "db.php";

$conn = connDB();

if(empty($_POST)) {
    $result = queryRestaurants($conn);
}
elseif ($_POST['county'] == 0) {
    if ($_POST['district'] == 0) {
        $result = query_hotels($conn);
    }
    else {
        $district = $_POST['district'];
        $result = query_hotels_district($conn,$district);
    }
}
else {
    $county = $_POST['county'];
    $result = query_hotels_county($conn,$county);
}

$rows = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc())
        array_push($rows, $row);
}

echo json_encode($rows);
?>
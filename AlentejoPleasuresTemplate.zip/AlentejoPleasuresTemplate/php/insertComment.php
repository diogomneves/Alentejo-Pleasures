<?php
/**
 * Created by PhpStorm.
 * User: Diogo
 * Date: 23/01/2019
 * Time: 16:26
 */

include_once "db.php";

$conn = connDB();

$result = false;

if(!empty($_POST)) {

    $comment = $_POST['comment'];
    $user_id = $_POST['user_id'];
    $local_id = $_POST['local_id'];
    $date = date('Y-m-d H:i:s');


    $result = insertComment($conn, $comment, $date, $user_id, $local_id);
}

echo json_encode($result);
?>
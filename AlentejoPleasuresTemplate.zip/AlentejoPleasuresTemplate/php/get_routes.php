<?php
/**
 * Created by PhpStorm.
 * User: Diogo
 * Date: 24/01/2019
 * Time: 10:46
 */

include_once "db.php";

$conn = connDB();

if(empty($_POST)) {
    $result = query_routes($conn);
}
elseif ($_POST['category'] == 0) {
        $result = query_hotels($conn);
    }
    else {
        $category = $_POST['category'];
        $result = query_route_by_category($conn,$category);
    }

$rows = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc())
        array_push($rows, $row);
}

echo json_encode($rows);
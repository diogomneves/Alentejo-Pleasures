<?php
/**
 * Created by PhpStorm.
 * User: Diogo
 * Date: 24/01/2019
 * Time: 10:46
 */

include_once "db.php";

$conn = connDB();
$result = query_routes($conn);

$rows = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc())
        array_push($rows, $row);
}

echo json_encode($rows);
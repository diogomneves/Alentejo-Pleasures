<?php
/**
 * Created by PhpStorm.
 * User: ESEB
 * Date: 04-12-2018
 * Time: 12:09
 */

function connDB ()
{
    $servername = "localhost";
    $username = "admin";
    $password = "Pleasures.RDD";
    $dbname = "alentejopleasures";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    $conn->set_charset('utf8mb4');

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    else {
        // echo "<br>","Ligado","<br>";
        return $conn;
    }
}

function endConnDB ($conn)
{
    $conn->close();
}

function query_districts($conn)
{
    $sql = "SELECT * FROM district";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function query_county_district ($conn,$district)
{
    $sql = "SELECT county.* 
            FROM county, district 
            WHERE county.district_id = district.district_id 
            AND district.district_id = '$district'";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function query_hotels($conn)
{
    $sql = "SELECT * FROM local WHERE local.category_id = 2 LIMIT 5";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}
function query_hotels_district ($conn,$district)
{
    $sql = "SELECT local.*
            FROM local , county , district
            WHERE local.county_id = county.county_id
            AND county.district_id = district.district_id
            AND local.category_id = 2 
            AND district.district_id ='$district'";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}
function query_hotels_county ($conn,$county)
{
    $sql = "SELECT local.* 
            FROM county, local, category 
            WHERE county.county_id = local.county_id 
            AND local.category_id = category.category_id 
            AND category.category_id = 2 
            AND county.county_id ='$county'";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function query_monuments($conn)
{
    $sql = "SELECT * FROM local WHERE local.category_id = 3 LIMIT 5";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}


function query_monuments_district($conn,$district)
{
    $sql = "SELECT local.*
            FROM local , county , district
            WHERE local.county_id = county.county_id
            AND county.district_id = district.district_id
            AND local.category_id = 3 
            AND district.district_id ='$district'";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function query_monuments_county ($conn,$county)
{
    $sql = "SELECT local.* 
            FROM county, local, category 
            WHERE county.county_id = local.county_id 
            AND local.category_id = category.category_id 
            AND category.category_id = 3
            AND county.county_id ='$county'";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}


function query_restaurant($conn)
{
    $sql = "SELECT * FROM local WHERE local.category_id = 1 LIMIT 5";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function query_restaurants_district($conn,$district)
{
    $sql = "SELECT local.*
            FROM local , county , district
            WHERE local.county_id = county.county_id
            AND county.district_id = district.district_id
            AND local.category_id = 1
            AND district.district_id ='$district'";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function query_restaurant_county ($conn,$county)
{
    $sql = "SELECT local.* 
            FROM county, local, category 
            WHERE county.county_id = local.county_id 
            AND local.category_id = category.category_id 
            AND category.category_id = 1
            AND county.county_id ='$county'";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function query_wines($conn)
{
    $sql = "SELECT * FROM local WHERE local.category_id = 6 LIMIT 5";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function query_wines_district($conn,$district)
{
    $sql = "SELECT local.*
            FROM local , county , district
            WHERE local.county_id = county.county_id
            AND county.district_id = district.district_id
            AND local.category_id = 6
            AND district.district_id ='$district'";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function query_wines_county ($conn,$county)
{
    $sql = "SELECT local.* 
            FROM county, local, category 
            WHERE county.county_id = local.county_id 
            AND local.category_id = category.category_id 
            AND category.category_id = 6
            AND county.county_id ='$county'";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}


function queryHotels_id($conn, $id)
{
    $sql = "SELECT * FROM local WHERE local_id = $id";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function queryHotelsPage($conn, $offset)
{
    $sql= "SELECT * FROM local WHERE `category_id`= 2 LIMIT 5 OFFSET '$offset'";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function query_categoy_route($conn)
{
    $sql = "SELECT * FROM route_category";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function query_route_by_category($conn, $category)
{
    $sql = "SELECT * FROM route WHERE route_category_id = $category";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}


function query_routes($conn)
{
    $sql = "SELECT * from route";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function query_routesId($conn, $id)
{
    $sql = "SELECT * FROM route WHERE route_id = $id";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function insertComment($conn, $comment, $date, $user_id, $local_id)
{
    $sql = "INSERT INTO comment (comment_id	, comment, date, user_id, local_id) VALUES ('','$comment', '$date', '$user_id', '$local_id')";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function getUserId($conn, $name)
{
    $sql = "SELECT user_id FROM user WHERE user.name = '$name'";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}


function query_beach($conn)
{
    $sql = "SELECT * FROM local WHERE local.category_id = 4 LIMIT 5";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function query_beach_district($conn,$district)
{
    $sql = "SELECT local.*
            FROM local , county , district
            WHERE local.county_id = county.county_id
            AND county.district_id = district.district_id
            AND local.category_id = 4
            AND district.district_id ='$district'";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function query_beach_county($conn,$county)
{
    $sql = "SELECT local.* 
            FROM county, local, category 
            WHERE county.county_id = local.county_id 
            AND local.category_id = category.category_id 
            AND category.category_id = 4
            AND county.county_id ='$county'";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}




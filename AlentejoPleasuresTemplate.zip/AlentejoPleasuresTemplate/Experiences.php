<!doctype html>
<html lang="pt">
<head>
    <title>Alentejo Pleasures</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <link rel="stylesheet" href="fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <!-- Theme Style -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="block-45">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <ul class="block-45-list">




                    <!-- VER SE ESTÀ LOGADO -->
                    <?php

                    include_once "QuerysUser.php";

                    session_start();

                    $nuser = new QuerysUser("", "", "");
                    $result = $nuser->check_session();

                    if ($result) {
                        echo $_SESSION['username'];
                        echo "<li><a></a></li>";
                        echo "<li><a href=\"php/logout.php\">Logout</a></li>";


                    }

                    else{

                        echo " <li><a href=\"Login.php\">Login</a></li>";
                        echo "<li><a href=\"Register.php\">Registar</a></li>";
                    }

                    ?>
                </ul>



            </div>
            <div class="col-md-6 text-md-right">
                <ul class="block-45-icons">
                    <li><a href="3"><span class="fa fa-facebook"></span></a></li>
                    <li><a href="3"><span class="fa fa-twitter"></span></a></li>
                    <li><a href="3"><span class="fa fa-linkedin"></span></a></li>
                    <li><a href="3"><span class="fa fa-instagram"></span></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>


<header role="banner">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand absolute" href="index.php">Alentejo Pleasures</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample05" aria-controls="navbarsExample05" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse navbar-light" id="navbarsExample05">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Hotels.php">Hóteis</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Monuments.php">Monumentos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Restaurants.php">Restaurantes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Adega.php">Vinhos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Route.php">Rotas</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="Experiences.php">Experiências</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="" id="dropdown05" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Sobre Nós</a>
                        <div class="dropdown-menu" aria-labelledby="dropdown05">
                            <a class="dropdown-item" href="Contact.php">Contactos</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
<!-- END header -->

    <section class="site-hero overlay" data-stellar-background-ratio="0.5" style="background-image: url(images/paisagem.jpg);">
        <div class="container">
            <div class="row align-items-center justify-content-center site-hero-inner">
                <div class="col-md-8 text-center">

                    <div class="mb-5 element-animate">
                        <div class="block-17">
                            <h1 class="heading mb-4">Experiências</h1>
                            <div class="lead">O Alentejo é também um lugar onde a paisagem deslumbrante se vem agora aliar à inovação de empresários com alma alentejana. Hoje, existem inúmeras atividades, levando-nos a ficar cada vez mais tempo neste destino tão aclamado internacionalmente nos últimos anos.</div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- END section -->





    <section class="site-section bg-light">
        <div class="container">

            <div class="row">
                <div class="col-md-6 col-lg-4 mb-5">
                    <div class="block-20">
                        <figure>
                            <a href="blog-single.html"><img src="images/azeite.jpg" alt="Image placeholder" class="img-fluid"></a>
                        </figure>
                        <div class="text text-center">
                            <h3 class="heading"><a href="#">Prove o azeite alentejano</a></h3>
                            <div class="meta mb-3">
                                <div><a href="#"><span class="fa fa-user"></span> Ricardo Mestre</a></div>
                            </div>
                            <p>Prova de azeite ou degustação de azeite alentejano é uma atividade que muitos visitantes procuram por ser algo tão natural e genuíno nesta região</p>
                            <p><a href="blog-single.html"><strong>Read More</strong></a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-5">
                    <div class="block-20">
                        <figure>
                            <a href="blog-single.html"><img src="images/Balão.jpg" alt="Image placeholder" class="img-fluid"></a>
                        </figure>
                        <div class="text text-center">
                            <h3 class="heading"><a href="#">Aventure-se pelos céus de balão</a></h3>
                            <div class="meta mb-3">
                                <div><a href="#"><span class="fa fa-user"></span> Diogo Neves</a></div>
                            </div>
                            <p>Subir aos céus a bordo de um balão de ar quente é para nós a forma mais romântica de voar, uma experiência de vida inesquecível.</p>
                            <p><a href="blog-single.html"><strong>Read More</strong></a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-5">
                    <div class="block-20">
                        <figure>
                            <a href="blog-single.html"><img src="images/enoturismo.jpg" alt="Image placeholder" class="img-fluid"></a>
                        </figure>
                        <div class="text text-center">
                            <h3 class="heading"><a href="#">Encontre o melhor do enoturismo</a></h3>
                            <div class="meta mb-3">
                                <div><a href="#"><span class="fa fa-user"></span> Diogo Guerreiro</a></div>
                            </div>
                            <p>O enoturismo baseia-se na viagem motivada pela apreciação do sabor e aroma dos vinhos, das tradições e cultura desta região.</p>
                            <p><a href="blog-single.html"><strong>Read More</strong></a></p>
                        </div>
                    </div>
                </div>


                <div class="col-md-6 col-lg-4 mb-5">
                    <div class="block-20">
                        <figure>
                            <a href="blog-single.html"><img src="images/alqueva.jpg" alt="Image placeholder" class="img-fluid"></a>
                        </figure>
                        <div class="text text-center">
                            <h3 class="heading"><a href="#">Maravilhoso Alqueva</a></h3>
                            <div class="meta mb-3">
                                <div><a href="#"><span class="fa fa-user"></span> Diogo Neves</a></div>
                            </div>
                            <p>Desfrute de um passeio de barco no maior lago artificial da Europa, descobrindo todas as aldeias ribeirinhas, castelos, paisagens envolventes e outras maravilhas do lago.</p>
                            <p><a href="blog-single.html"><strong>Read More</strong></a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-5">
                    <div class="block-20">
                        <figure>
                            <a href="blog-single.html"><img src="images/gastronomia.jpg" alt="Image placeholder" class="img-fluid"></a>
                        </figure>
                        <div class="text text-center">
                            <h3 class="heading"><a href="#">Gastronomia</a></h3>
                            <div class="meta mb-3">
                                <div><a href="#"><span class="fa fa-user"></span> Ricardo Mestre</a></div>
                            </div>
                            <p>A criatividade e a imaginação na utilização de ingredientes simples fizeram da gastronomia alentejana uma surpresa de sabores. </p>
                            <p><a href="blog-single.html"><strong>Read More</strong></a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-5">
                    <div class="block-20">
                        <figure>
                            <a href="blog-single.html"><img src="images/abetarda.jpg" alt="Image placeholder" class="img-fluid"></a>
                        </figure>
                        <div class="text text-center">
                            <h3 class="heading"><a href="#">Birdwatching</a></h3>
                            <div class="meta mb-3">
                                <div><a href="#"><span class="fa fa-user"></span> Diogo Guerreiro</a></div>
                            </div>
                            <p>Experiencie os magnificos passeios para observação de aves no Alentejo. Venha conhecer as muitas espécies de aves que povoam os nossos campos. </p>
                            <p><a href="blog-single.html"><strong>Read More</strong></a></p>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </section>



    <footer class="site-footer">
        <div class="container">
            <div class="row mb-5">
                <div class="col-md-6 col-lg-3 mb-5 mb-lg-0">
                    <h3 class="heading">Contactos</h3>
                    <div class="block-23 float-md-right">
                        <ul>
                            <li><span class="icon ion-android-pin"></span><span class="text">Rua Coronel Manuel Emidio Lt.4 - Évora</span></li>
                            <li><a href="#"><span class="icon ion-ios-telephone"></span><span class="text">266 754 890</span></a></li>
                            <li><a href="#"><span class="icon ion-android-mail"></span><span class="text">alentejopleasures@gmail.com</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row pt-5">
                <div class="col-md-12 text-center copyright">

                    <p class="float-md-left"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Alentejo Pleasures
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                    <p class="float-md-right">
                        <a href="#" class="fa fa-facebook p-2"></a>
                        <a href="#" class="fa fa-twitter p-2"></a>
                        <a href="#" class="fa fa-linkedin p-2"></a>
                        <a href="#" class="fa fa-instagram p-2"></a>

                    </p>
                </div>
            </div>
        </div>
    </footer>
    <!-- END footer -->

</div>

<!-- loader -->
<div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#f4b214"/></svg></div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/jquery-migrate-3.0.0.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>

<script src="js/jquery.magnific-popup.min.js"></script>

<script src="js/main.js"></script>
</body>
</html>
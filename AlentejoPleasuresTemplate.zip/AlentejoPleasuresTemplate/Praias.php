<!doctype html>
<html lang="pt">
<head>
    <title>Alentejo Pleasures</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <link rel="stylesheet" href="fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <!-- Theme Style -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="block-45">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <ul class="block-45-list">


                    <!-- VER SE ESTÀ LOGADO -->
                    <?php

                    include_once "QuerysUser.php";

                    session_start();

                    $nuser = new QuerysUser("", "", "");
                    $result = $nuser->check_session();

                    if ($result) {
                        echo $_SESSION['username'];
                        echo "<li><a></a></li>";
                        echo "<li><a href=\"php/logout.php\">Logout</a></li>";


                    }

                    else{

                        echo " <li><a href=\"Login.php\">Login</a></li>";
                        echo "<li><a href=\"Register.php\">Registar</a></li>";
                    }

                    ?>
                </ul>

            </div>
            <div class="col-md-6 text-md-right">
                <ul class="block-45-icons">
                    <li><a href="3"><span class="fa fa-facebook"></span></a></li>
                    <li><a href="3"><span class="fa fa-twitter"></span></a></li>
                    <li><a href="3"><span class="fa fa-linkedin"></span></a></li>
                    <li><a href="3"><span class="fa fa-instagram"></span></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<header role="banner">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand absolute" href="index.php">Alentejo Pleasures</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample05" aria-controls="navbarsExample05" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse navbar-light" id="navbarsExample05">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Hotels.php">Hóteis</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Monuments.php">Monumentos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Restaurants.php">Restaurantes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Adega.php">Vinhos</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="Praias.php">Praias</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Route.php">Rotas</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Experiences.php">Experiências</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="" id="dropdown05" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Sobre Nós</a>
                        <div class="dropdown-menu" aria-labelledby="dropdown05">
                            <a class="dropdown-item" href="Contact.php">Contactos</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
<!-- END header -->

<section class="site-hero overlay" data-stellar-background-ratio="0.5" style="background-image: url(images/praias.jpg);">
    <div class="container">
        <div class="row align-items-center justify-content-center site-hero-inner">
            <div class="col-md-8 text-center">

                <div class="mb-5 element-animate">
                    <div class="block-17">

                        <h1 class="heading mb-4">Praias</h1>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<!-- END section -->


<section class="site-section bg-light">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="block-36">
                    <h3 class="block-36-heading">Pesquisar por:</h3>
                    <ul>
                        <form>
                            <label for="id_d">Distritos:</label>
                            <br>
                            <select id="id_d" name="id_ctype" width="200" style="width: 200px">
                                <option value="0">Todos</option>
                            </select>
                            <br><br>
                            <label for="id_c">Concelho:</label>
                            <br>
                            <select id="id_c" name="id_c" width="200" style="width: 200px">
                                <option value="0">Todos</option>
                            </select>
                            <br><br>
                            <input id="add" type="button" value="Filtrar" style="border-radius: 4px;">
                        </form>
                    </ul>
                </div>
            </div>

            <div class="col-md-8 pl-md-5" id="list">

                <style>

                </style>

                <table  id="table">
                    <tr><td style="font-family: 'Georgia'; font-size: 20px; text-align: center" id="name1" align="center" ></td></tr>
                    <tr><td style="padding: 20px" align="center"  id="image1"></td>
                        <td style="padding: 30px" align="center" id="description1"></td></tr>

                    <tr><td style="font-family: 'Georgia'; font-size: 20px; text-align: center" id="name2" align="center" ></td></tr>
                    <tr><td style="padding: 15px" id="image2" align="center" ></td>
                        <td style="padding: 30px" id="description2"></td></tr>

                    <tr><td style="font-family: 'Georgia'; font-size: 20px; text-align: center" id="name3" align="center" ></td></tr>
                    <tr><td style="padding: 15px" width="200px" height="300px" id="image3" align="center"></td>
                        <td style="padding: 30px" id="description3"></td></tr>

                    <tr><td style="font-family: 'Georgia'; font-size: 20px; text-align: center" id="name4" align="center" ></td></tr>
                    <tr><td style="padding: 15px" id="image4" align="center"></td>
                        <td style="padding: 30px"id="description4"></td></tr>

                    <tr><td style="font-family: 'Georgia'; font-size: 20px; text-align: center" id="name5" align="center" ></td></tr>
                    <tr><td style="padding: 15px" id="image5" align="center" ></td>
                        <td style="padding: 30px" id="description5"></td></tr>
                </table>
            </div>
        </div>

        <div class="row mt-5">
            <div class="col-md-12 pt-5">
                <ul class="pagination custom-pagination">
                    <li id="anterior" class="page-item"><a class="page-link" href="#"> &lt; </a></li>
                    <li id="seguinte" class="page-item"><a class="page-link" href="#"> &gt;  </a></li>
                </ul>
            </div>
        </div>
    </div>
</section>

<footer class="site-footer">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-6 col-lg-3 mb-5 mb-lg-0">
                <h3 class="heading">Contactos</h3>
                <div class="block-23 float-md-right">
                    <ul>
                        <li><span class="icon ion-android-pin"></span><span class="text">Rua Coronel Manuel Emidio Lt.4 - Évora</span></li>
                        <li><a href="#"><span class="icon ion-ios-telephone"></span><span class="text">266 754 890</span></a></li>
                        <li><a href="#"><span class="icon ion-android-mail"></span><span class="text">alentejopleasures@gmail.com</span></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="row pt-5">
            <div class="col-md-12 text-center copyright">

                <p class="float-md-left"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Alentejo Pleasures
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                <p class="float-md-right">
                    <a href="#" class="fa fa-facebook p-2"></a>
                    <a href="#" class="fa fa-twitter p-2"></a>
                    <a href="#" class="fa fa-linkedin p-2"></a>
                    <a href="#" class="fa fa-instagram p-2"></a>

                </p>
            </div>
        </div>
    </div>
</footer>
<!-- END footer -->

</div>

<!-- loader -->
<div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#f4b214"/></svg></div>


<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/jquery-migrate-3.0.0.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>

<script src="js/jquery.magnific-popup.min.js"></script>

<script src="js/main.js"></script>


<script>

    var offset = 1;

    $( document ).ready(function() {
        // obtem todos os distritos e adiciona-os ao select
        $.post(
            "php/get_district.php",
            {},
            function (data, status) {
                if (status == "success") {
                    var objData = JSON.parse(data);
                    for (item in objData) {
                        $("select#id_d").append("<option value='" + objData[item].district_id + "'>" + objData[item].name + "</option>");
                    }
                }
            }
        )

        // obtem todos os hoteis e adiciona-os ao div
        $.post(
            "php/get_beach.php",
            {},
            function (data, status) {
                if (status == "success") {

                    strn = "td#name";
                    stri = "td#image";
                    strd = "td#description";

                    var col = 1;
                    var objData = JSON.parse(data);
                    for (item in objData) {
                        $(strn + col).text(objData[item].name);
                        $(stri + col).html("<a href=" + "'Details.php?local_id=" + objData[item].local_id + "'>" +
                            "<img src='" + objData[item].image + "' alt=''  height='200'></a>");
                        $(strd + col).text(objData[item].description.slice(0, 200) + "...");
                        col++;
                    }
                }
            }
        )


        /*
                $.post(
                    "php/get_hotels.php",
                    {},
                    function(data, status){
                        if (status == "success")
                        {
                            var col = 1;
                            strn = "td#name";
                            stri = "td#image";
                            strd = "td#description";
                            var objData = JSON.parse(data);
                            for (item in objData) {
                                $(strn + col).text(objData[item].name);
                                $(stri + col).html("<a href=" + "'detalhesHotel.php?local_id=" + objData[item].local_id + "'>" +
                                    "<img src='" + objData[item].image + "' alt=''  height='200'></a>");
                                $(strd + col).text(objData[item].description.slice(0,200) + "...");
                                col++;

                            }
                        }
                    }
                )
            });*/

        // quando o select do distrito é alterado
        $("select#id_d").change(function () {
            var id = $("select#id_d").val();

            // limpa - coloca só a opção Todos
            $("select#id_c").html("<option value='0'>Todos</option>");

            // obtem os concelhos do distrito id
            $.post(
                "php/get_county.php",
                {
                    district: id
                },
                function (data, status) {
                    if (status == "success") {
                        var objData = JSON.parse(data);
                        for (item in objData) {
                            $("select#id_c").append("<option value='" + objData[item].county_id + "'>" + objData[item].name + "</option>");
                        }
                    }
                }
            )
        });


        // quando o select do concelho é alterado
        $("select#id_c").change(function () {
            var idd = $("select#id_d").val();
            var idc = $("select#id_c").val();

            // obtem os concelhos do distrito id
            $.post(
                "php/get_beach.php",
                {
                    district: idd,
                    county: idc
                },
                function (data, status) {
                    if (status == "success") {
                        var objData = JSON.parse(data);
                        for (item in objData) {
                            $("select#id_c").append("<option value='" + objData[item].county_id + "'>" + objData[item].name + "</option>");
                        }
                    }
                }
            )
        });

        // filtra os hoteis
        $("input#add").click(function () {
            // obtem os ids
            var idd = $("select#id_d").val();
            var idc = $("select#id_c").val();

            // limpa a lista
            $("table#table td").html("");
            $("table#table td").text("");

            // obtem os hoteis do concelho ou do distrito
            $.post(
                "php/get_beach.php",
                {
                    district: idd,
                    county: idc
                },
                function(data, status){
                    if (status == "success")
                    {

                        var col = 1;
                        strn = "td#name";
                        stri = "td#image";
                        strd = "td#description";

                        var objData = JSON.parse(data);

                        for (item in objData) {
                            $(strn + col).text(objData[item].name);
                            $(stri + col).html("<a href=" + "'Details.php?local_id=" + objData[item].local_id + "'>" +
                                "<img src='" + objData[item].image + "' alt=''  height='200'></a>");
                            $(strd + col).text(objData[item].description.slice(0, 200) + "...");
                            col++;
                        }
                    }
                }
            )
        });
    });





</script>
</body>
</html>



<?php
/**
 * Created by PhpStorm.
 * User: ESEB
 * Date: 15-11-2018
 * Time: 12:22
 */

class User
{
    public $name, $password, $conn;

    public function __construct($name, $password)
    {
        $this->name = $name;
        $this->password = $password;
        $this->conn = $this->connDB();
    }

    public function connDB ()
    {
        $servername = "localhost";
        $username = "admin";
        $password = "Pleasures.RDD";
        $dbname = "alentejopleasures";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        else {
            return $conn;
        }
    }

    public function endConnDB ()
    {
        $this->conn->close();
    }


    public function login()
    {
        $sql = "SELECT name, password FROM User WHERE name='$this->name' AND password='$this->password'";
        $result = $this->conn->query($sql);
        $this->endConnDB();
        return $result;
    }
}
<?php
/**
 * Created by PhpStorm.
 * User: ESEB
 * Date: 15-11-2018
 * Time: 12:55
 */

?>

<!DOCTYPE HTML>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <style>
        .error {
            color: #FF0000;
        }
    </style>
</head>
<body>

<?php

include_once "User.php";

// define variables and set to empty values
$nameErr = $passwordErr = "";
$name = $password = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["name"])) {
        $nameErr = "O nome é obrigatório!";
    } else {
        $name = test_input($_POST["name"]);
        // check if name only contains letters
        if ($name !== "admin") {
            $nameErr = "O nome de utilizador está incorreto!";
        }
    }

    if (empty($_POST["password"])) {
        $passwordErr = "A senha é obrigatória!";
    } else {
        $password = test_input($_POST["password"]);
    }
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>

<h2 style="width: 100%; text-align:center;">Login</h2>
<p style="width: 100%; text-align:center;"><span class="error">* preenchimento obrigatório</span></p>
<form style="width: 100%;text-align:center;" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    Nome: <input type="text" name="name" value="<?php echo $name; ?>">
    <span class="error">* <?php echo $nameErr; ?></span>
    <br><br>
    Senha: <input type="password" name="password" value="<?php echo $password; ?>">
    <span class="error">* <?php echo $passwordErr; ?></span>
    <br><br>
    <input type="submit" name="submit" value="Submeter">
</form>

<?php

if (isset($_POST['submit']) && $nameErr=="" && $passwordErr=="")
{
    $nuser = new User($name,$password);
    $result = $nuser->login();
    if ($result->num_rows == 1)
    {
        header("Location: Menu.html");
        echo "Utilizador ",$name," fez login com sucesso!";
    }
    else
        echo "Erro no login";
}

?>

</body>
</html>
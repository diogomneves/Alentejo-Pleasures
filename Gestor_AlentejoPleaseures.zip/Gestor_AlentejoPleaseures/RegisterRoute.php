<?php
/**
 * Created by PhpStorm.
 * User: ESEB
 * Date: 15-11-2018
 * Time: 12:55
 */

?>

<!DOCTYPE HTML>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <style>
        .error {
            color: #FF0000;
        }
    </style>
</head>
<body>

<?php

include_once "Route.php";

// define variables and set to empty values
$route_idErr = $nameErr = $descriptionErr = $imageErr = $route_categoryErr = "";
$route_id = $name = $description = $image = $route_category = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["route_id"])) {
        $route_idErr = "O id da rota é obrigatório!";
    } else {
        $route_id = test_input($_POST["route_id"]);
    }

    if (empty($_POST["name"])) {
        $nameErr = "O nome é obrigatório!";
    } else {
        $name = test_input($_POST["name"]);
    }

    if (empty($_POST["description"])) {
        $descriptionErr = "A descrição é obrigatória!";
    } else {
        $description = test_input($_POST["description"]);
    }

    if (empty($_POST["image"])) {
        $imageErr = "O url da imagem é obrigatório!";
    } else {
        $image = test_input($_POST["image"]);
    }

    if (empty($_POST["route_category"])) {
        $route_categoryErr = "A categoria é obrigatória!";
    } else {
        $route_category = test_input($_POST["route_category"]);
    }
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>

<h2 style="width: 100%; text-align:center;">Registrar Rota</h2>
<p><span class="error">* preenchimento obrigatório</span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    Id da rota: <input type="text" name="route_id" value="<?php echo $route_id; ?>">
    <span class="error">* <?php echo $route_idErr; ?></span>
    <br><br>
    Nome: <input type="text" name="name" value="<?php echo $name; ?>">
    <span class="error">* <?php echo $nameErr; ?></span>
    <br><br>
    Descrição: <input type="text" name="description" value="<?php echo $description; ?>">
    <span class="error">* <?php echo $descriptionErr; ?></span>
    <br><br>
    Imagem: <input type="text" name="image" value="<?php echo $image; ?>">
    <span class="error">* <?php echo $imageErr; ?></span>
    <br><br>
    Categoria: <input type="text" name="route_category" value="<?php echo $route_category; ?>">
    <span class="error">* <?php echo $route_categoryErr; ?></span>
    <br><br>
    <input type="submit" name="submit" value="Submeter">
</form>

<?php
if (isset($_POST['submit']) && $route_idErr=="" && $nameErr=="" && $descriptionErr=="" && $imageErr=="" && $route_categoryErr=="")
{
    $nroute = new Route($route_id, $name, $description, $image, $route_category);
    $result = $nroute->insert_route();
    echo "<br>";
    if ($result)
        echo "Rota ",$name," registada com sucesso!";
    else
        echo "Erro no registo.";
}

?>

<p><a href="Menu.html">Voltar ao Menu</a></p>

</body>
</html>

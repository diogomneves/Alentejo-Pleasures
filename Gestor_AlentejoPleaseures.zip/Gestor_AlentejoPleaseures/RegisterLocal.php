<?php
/**
 * Created by PhpStorm.
 * User: ESEB
 * Date: 15-11-2018
 * Time: 12:55
 */

?>

<!DOCTYPE HTML>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <style>
        .error {
            color: #FF0000;
        }
    </style>
</head>
<body>

<?php

include_once "Local.php";

// define variables and set to empty values
$nameErr = $addressErr = $imageErr = $descriptionErr = $locationErr = $scheduleErr = $countyErr = $categoryErr = "";
$name = $address = $image = $description = $location = $schedule = $county = $category = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["name"])) {
        $nameErr = "O nome é obrigatório!";
    } else {
        $name = test_input($_POST["name"]);
    }


    if (empty($_POST["address"])) {
        $addressErr = "A morada é obrigatória!";
    } else {
        $address = test_input($_POST["address"]);
    }

    if (empty($_POST["image"])) {
        $imageErr = "O url da imagem é obrigatório!";
    } else {
        $image = test_input($_POST["image"]);
    }

    if (empty($_POST["description"])) {
        $descriptionErr = "A descrição é obrigatória!";
    } else {
        $description = test_input($_POST["description"]);
    }

    if (empty($_POST["location"])) {
        $locationErr = "A localização é obrigatória!";
    } else {
        $location = test_input($_POST["location"]);
    }

    if (empty($_POST["schedule"])) {
        $scheduleErr = "O horário é obrigatório!";
    } else {
        $schedule = test_input($_POST["schedule"]);
    }

    if (empty($_POST["county"])) {
        $countyErr = "O concelho é obrigatório!";
    } else {
        $county = test_input($_POST["county"]);
    }

    if (empty($_POST["category"])) {
        $categoryErr = "A categoria é obrigatória!";
    } else {
        $category = test_input($_POST["category"]);
    }
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>

<h2 style="width: 100%; text-align:center;">Registrar Local</h2>
<p><span class="error">* preenchimento obrigatório</span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    Nome: <input type="text" name="name" value="<?php echo $name; ?>">
    <span class="error">* <?php echo $nameErr; ?></span>
    <br><br>
    Morada: <input type="text" name="address" value="<?php echo $address; ?>">
    <span class="error">* <?php echo $addressErr; ?></span>
    <br><br>
    Imagem: <input type="text" name="image" value="<?php echo $image; ?>">
    <span class="error">* <?php echo $imageErr; ?></span>
    <br><br>
    Descrição: <input type="text" name="description" value="<?php echo $description; ?>">
    <span class="error">* <?php echo $descriptionErr; ?></span>
    <br><br>
    Localização: <input type="text" name="location" value="<?php echo $location; ?>">
    <span class="error">* <?php echo $locationErr; ?></span>
    <br><br>
    Horário: <input type="text" name="schedule" value="<?php echo $schedule; ?>">
    <span class="error">* <?php echo $scheduleErr; ?></span>
    <br><br>
    Id do concelho: <input type="text" name="county" value="<?php echo $county; ?>">
    <span class="error">* <?php echo $countyErr; ?></span>
    <br><br>
    Id da categoria: <input type="text" name="category" value="<?php echo $category; ?>">
    <span class="error">* <?php echo $categoryErr; ?></span>
    <br><br>
    <input type="submit" name="submit" value="Submeter">
</form>

<?php
if (isset($_POST['submit']) && $nameErr=="" && $addressErr=="" && $imageErr=="" && $descriptionErr=="" && $locationErr=="" && $scheduleErr==""&& $countyErr=="" && $categoryErr=="")
{
    $nlocal = new Local($name, $address, $image, $description, $location, $schedule, $county, $category);
    $result = $nlocal->insert_local();
    echo "<br>";
    if ($result)
        echo "Local ",$name," registado com sucesso!";
    else
        echo "Erro no registo.";
}

?>

<p><a href="Menu.html">Voltar ao Menu</a></p>

</body>
</html>

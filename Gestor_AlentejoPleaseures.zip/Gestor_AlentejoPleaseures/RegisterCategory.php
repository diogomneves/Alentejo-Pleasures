<?php
/**
 * Created by PhpStorm.
 * User: ESEB
 * Date: 15-11-2018
 * Time: 12:55
 */

?>

<!DOCTYPE HTML>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <style>
        .error {
            color: #FF0000;
        }
    </style>
</head>
<body>

<?php

include_once "Category.php";

// define variables and set to empty values
$categoryErr = "";
$category = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["category"])) {
        $categoryErr = "A categoria é obrigatória!";
    } else {
        $category = test_input($_POST["category"]);
    }
}




function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>

<h2 style="width: 100%; text-align:center;">Registrar Categoria</h2>
<p><span class="error">* preenchimento obrigatório</span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    Categoria: <input type="text" name="category" value="<?php echo $category; ?>">
    <span class="error">* <?php echo $categoryErr; ?></span>
    <br><br>
    <input type="submit" name="submit" value="Submeter">
</form>

<?php
if (isset($_POST['submit']) && $categoryErr=="")
{
    $ncategory = new Category($category);
    $result = $ncategory->insert_category();
    echo "<br>";
    if ($result)
        echo "Categoria de rotas ",$category," registada com sucesso!";
    else
        echo "Erro no registo.";
}

?>

<p><a href="Menu.html">Voltar ao Menu</a></p>

</body>
</html>

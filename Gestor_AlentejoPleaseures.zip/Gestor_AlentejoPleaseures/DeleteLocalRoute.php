<?php
/**
 * Created by PhpStorm.
 * User: ESEB
 * Date: 15-11-2018
 * Time: 12:55
 */

?>

<!DOCTYPE HTML>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <style>
        .error {
            color: #FF0000;
        }
    </style>
</head>
<body>

<?php

include_once "LocalRouteDelete.php";

$local_route_id = "";
$n_local_route = new LocalRouteDelete("","","");
$result = $n_local_route->query();

echo "<h2>Apagar Local_Rota<h2>";

if ($result->num_rows > 0) {
    echo "<select name='local_route_id' form='formid'>";
    while ($row = $result->fetch_assoc())
        echo "<option value=", $row["local_route_id"], ">", $row["local_route_id"], "</option>";
    echo "</select>";
} else {
    echo "Sem local_rota!";
}

?>

<form id="formid" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <br><br>
    <input type="submit" name="submit" value="Submeter">
</form>

<?php

if (isset($_POST['local_route_id'])) {
    $name = $_POST['local_route_id'];
    $n_local_route = new LocalRouteDelete($local_route_id,"","");
    $result = $n_local_route->delete_local_route();
    echo "<br>";
    if ($result)
        echo "Local_rota apagada!";
    else
        echo "Erro ao apagar local_rota";
}
?>

<p><a href="Menu.html">Voltar ao Menu</a></p>

</body>
</html>

<?php
/**
 * Created by PhpStorm.
 * User: ESEB
 * Date: 15-11-2018
 * Time: 12:55
 */

?>

<!DOCTYPE HTML>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <style>
        .error {
            color: #FF0000;
        }
    </style>
</head>
<body>

<?php

include_once "RouteCategory.php";

// define variables and set to empty values
$route_categoryErr = "";
$route_category = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["route_category"])) {
        $route_categoryErr = "A categoria é obrigatória!";
    } else {
        $route_category = test_input($_POST["route_category"]);
    }
}




function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>

<h2 style="width: 100%; text-align:center;">Registrar Categoria de Rotas</h2>
<p><span class="error">* preenchimento obrigatório</span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    Categoria: <input type="text" name="route_category" value="<?php echo $route_category; ?>">
    <span class="error">* <?php echo $route_categoryErr; ?></span>
    <br><br>
    <input type="submit" name="submit" value="Submeter">
</form>

<?php
if (isset($_POST['submit']) && $route_categoryErr=="")
{
    $nroute_category = new RouteCategory($route_category);
    $result = $nroute_category->insert_route_category();
    echo "<br>";
    if ($result)
        echo "Categoria de rotas ",$route_category," registada com sucesso!";
    else
        echo "Erro no registo.";
}

?>

<p><a href="Menu.html">Voltar ao Menu</a></p>

</body>
</html>

<?php
/**
 * Created by PhpStorm.
 * User: ESEB
 * Date: 15-11-2018
 * Time: 12:22
 */

class Route
{
    public $route_id, $name, $image, $description, $route_category, $conn;

    public function __construct($route_id, $name, $image, $description, $route_category)
    {
        $this->route_id = $route_id;
        $this->name = $name;
        $this->image = $image;
        $this->description = $description;
        $this->route_category = $route_category;
        $this->conn = $this->connDB();
    }


    public function connDB ()
    {
        $servername = "localhost";
        $username = "admin";
        $password = "Pleasures.RDD";
        $dbname = "alentejopleasures";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        $conn->set_charset('utf8mb4');

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        else {
            return $conn;
        }
    }

    public function endConnDB ()
    {
        $this->conn->close();
    }


    function insert_route ()
    {
        $sql = "INSERT INTO route(route_id, name, description, image, route_category_id) VALUES ('$this->route_id', '$this->name','$this->description','$this->image','$this->route_category')";
        $result = $this->conn->query($sql);
        $this->endConnDB();
        return $result;
    }

    public function query()
    {
        $sql = "SELECT * FROM route";
        $result = $this->conn->query($sql);
        $this->endConnDB();
        return $result;
    }

    public function deleteRoute()
    {
        $sql = "DELETE FROM route WHERE name='$this->name'";
        $result = $this->conn->query($sql);
        $this->endConnDB();
        return $result;
    }
}
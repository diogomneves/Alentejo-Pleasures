<?php
/**
 * Created by PhpStorm.
 * User: ESEB
 * Date: 15-11-2018
 * Time: 12:22
 */

class LocalRouteInsert
{
    public $local_id, $route_id, $conn;

    public function __construct($local_id, $route_id)
    {
        $this->local_id = $local_id;
        $this->route_id = $route_id;
        $this->conn = $this->connDB();
    }


    public function connDB ()
    {
        $servername = "localhost";
        $username = "admin";
        $password = "Pleasures.RDD";
        $dbname = "alentejopleasures";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        else {
            return $conn;
        }
    }

    public function endConnDB ()
    {
        $this->conn->close();
    }


    function insert_local_route ()
    {
        $sql = "INSERT INTO local_route(local_id , route_id) VALUES ('$this->local_id', '$this->route_id')";
        $result = $this->conn->query($sql);
        $this->endConnDB();
        return $result;
    }
}
<?php
/**
 * Created by PhpStorm.
 * User: ESEB
 * Date: 15-11-2018
 * Time: 12:22
 */

class Local
{
    public $name, $address, $image, $description, $location, $schedule, $county, $category, $conn;

    public function __construct($name, $address, $image, $description, $location, $schedule, $county, $category)
    {
        $this->name = $name;
        $this->address = $address;
        $this->image = $image;
        $this->description = $description;
        $this->location = $location;
        $this->schedule = $schedule;
        $this->county = $county;
        $this->category = $category;
        $this->conn = $this->connDB();
    }


    public function connDB ()
    {
        $servername = "localhost";
        $username = "admin";
        $password = "Pleasures.RDD";
        $dbname = "alentejopleasures";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        $conn->set_charset('utf8mb4');

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        else {
            return $conn;
        }
    }

    public function endConnDB ()
    {
        $this->conn->close();
    }


    function insert_local ()
    {
        $sql = "INSERT INTO local(name, address, image, description, location, schedule, county_id, category_id) VALUES ('$this->name','$this->address','$this->image','$this->description','$this->location','$this->schedule','$this->county','$this->category')";
        $result = $this->conn->query($sql);
        $this->endConnDB();
        return $result;
    }

    public function query()
    {
        $sql = "SELECT * FROM local";
        $result = $this->conn->query($sql);
        $this->endConnDB();
        return $result;
    }

    public function deleteLocal()
    {
        $sql = "DELETE FROM local WHERE name='$this->name'";
        $result = $this->conn->query($sql);
        $this->endConnDB();
        return $result;
    }
}
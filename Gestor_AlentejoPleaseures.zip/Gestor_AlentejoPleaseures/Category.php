<?php
/**
 * Created by PhpStorm.
 * User: ESEB
 * Date: 15-11-2018
 * Time: 12:22
 */

class Category
{
    public $category, $conn;

    public function __construct($category)
    {
        $this->category = $category;
        $this->conn = $this->connDB();
    }


    public function connDB ()
    {
        $servername = "localhost";
        $username = "admin";
        $password = "Pleasures.RDD";
        $dbname = "alentejopleasures";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        $conn->set_charset('utf8mb4');

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        else {
            return $conn;
        }
    }

    public function endConnDB ()
    {
        $this->conn->close();
    }


    function insert_category ()
    {
        $sql = "INSERT INTO category(category) VALUES ('$this->category')";
        $result = $this->conn->query($sql);
        $this->endConnDB();
        return $result;
    }

    public function query()
    {
        $sql = "SELECT * FROM category";
        $result = $this->conn->query($sql);
        $this->endConnDB();
        return $result;
    }

    public function delete_category()
    {
        $sql = "DELETE FROM category WHERE category='$this->category'";
        $result = $this->conn->query($sql);
        $this->endConnDB();
        return $result;
    }
}
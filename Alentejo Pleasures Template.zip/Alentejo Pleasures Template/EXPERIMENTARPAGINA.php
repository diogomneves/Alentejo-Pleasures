<!doctype html>
<html lang="pt">
<head>
    <title>Alentejo Pleasures</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <link rel="stylesheet" href="fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <!-- Theme Style -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="block-45">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <ul class="block-45-list">
                    <img src="images/person.png" alt="Avatar" style="width:40px; border-radius: 50%; align="right";>

                    <!-- VER SE ESTÀ LOGADO -->
                    <?php

                    session_start();

                    echo $_SESSION['username'];

                    ?>
                </ul>


            </div>
            <div class="col-md-6 text-md-right">
                <ul class="block-45-icons">

                    <li><a href="login.php">Login</a></li>
                    <li><a href="registo.php">Registar</a></li>

                </ul>
            </div>

        </div>
    </div>
</div>


<header role="banner">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand absolute" href=index.php">Alentejo Pleasures</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample05" aria-controls="navbarsExample05" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse navbar-light" id="navbarsExample05">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="monumentos.php">Monumentos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="rotas.php">Rotas</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="hoteis.html">Hóteis</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="experiencias.php">Experiências</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="" id="dropdown05" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Sobre Nós</a>
                        <div class="dropdown-menu" aria-labelledby="dropdown05">
                            <a class="dropdown-item" href="colaboradores.php">Colaboradores</a>
                            <a class="dropdown-item" href="contactos.php">Contactos</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
<!-- END header -->



<section class="site-hero overlay" data-stellar-background-ratio="0.5" style="background-image: url(images/hoteis2.jpg);">
    <div class="container">
        <div class="row align-items-center justify-content-center site-hero-inner">
            <div class="col-md-8 text-center">

                <div class="mb-5 element-animate">
                    <div class="block-17">

                        <h1 class="heading mb-4">Hóteis</h1>
                        <span class="lead">ESCREVER ALGO</span>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<!-- END section -->





<section class="site-section bg-light">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="block-36">
                    <h3 class="block-36-heading">Pesquisar por:</h3>
                    <ul>
                        <form>

                            <li class="active"><a>Distrito:</a></li>
                            <select id="id_ctype" name="id_ctype">
                                <option value="0">None</option>
                            </select>
                            <li class="active"><a>Concelho:</a></li>
                            <select id="id_c" name="id_c">
                            </select>
                            <br><br>
                            <input style="border-radius: 8px; position: center; color: orange;" id="add" type="button" value="Filtrar">
                        </form>



                    </ul>
                </div>
            </div>
            <div class="col-md-8 pl-md-5">
                <div class="block-44 d-flex mb-3">
                    <div class="block-44-text">
                        <div class="block-44-icons">

                            <!--  <form>
                              <table id="table_hotel" class="tg" style="border-collapse:collapse;border-spacing:2px;">
                                  <tr>
                                      <th id="nome" name="nome"></th>
                                  </tr>
                                  <tr>
                                      <td id="imagem" name="imagem"></td>
                                  <tr></tr>
                                      <td id="descricao" name="descricao"></td>
                                  </tr>

                              </table>
                              </form> -->

                            <?php
                            //pagination.php
                            $connect = mysqli_connect("localhost", "twdm", "password", "alentejopleasures");
                            $connect-> set_charset('utf8mb4');
                            $record_per_page = 5;
                            $page = '';
                            $output = '';
                            if(isset($_POST["page"]))
                            {
                                $page = $_POST["page"];
                            }
                            else
                            {
                                $page = 1;
                            }
                            $start_from = ($page - 1)*$record_per_page;
                            $query = "SELECT * FROM local ORDER BY local_id DESC LIMIT $start_from, $record_per_page";
                            $result = mysqli_query($connect, $query);
                            $output .= "  
  
  <table class='table table-bordered' style='align=center; border=4; cellspacing=10; cellpadding=4; height: 10% '> 
           <tr>  
                <th width='50%'>Name</th>   
                <th width='50%'>Image</th>
           </tr>";

                            while($row = mysqli_fetch_array($result))
                            {
                                $output .= '  
           <tr>  
                <td>'.$row["name"].'</td>
                </tr>
                <td ><img  src="' . $row['image'] .'" height=\'250\' width=\'350\'></td>
                <td style="width: 50px ">'.$row["description"].'</td>  
           </tr>  
           
      
           
           
           
           
      ';
                            }
                            $output .= '</table><br /><div align="center">';
                            $page_query = "SELECT * FROM local ORDER BY local_id DESC";
                            $page_result = mysqli_query($connect, $page_query);
                            $total_records = mysqli_num_rows($page_result);
                            $total_pages = ceil($total_records/$record_per_page);
                            for($i=1; $i<=$total_pages; $i++)
                            {
                                $output .= "<span class='pagination_link' style='cursor:pointer; padding:6px; border:1px solid #ccc;' id='".$i."'>".$i."</span>";
                            }
                            $output .= '</div><br /><br />';
                            echo $output;
                            ?>







                            <script>
                                // onclick event is assigned to the #button element.
                                document.getElementById("image").onclick = function() {
                                    window.location.href = "index.php";
                                };
                            </script>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
</body>
</html>

<script>
    $(document).ready(function(){
        load_data();
        function load_data(page)
        {
            $.ajax({
                url:"#",
                method:"POST",
                data:{page:page},
                success:function(data){
                    $('#pagination_data').html(data);
                }
            })
        }
        $(document).on('click', '.pagination_link', function(){
            var page = $(this).attr("id");
            load_data(page);
        });
    });
</script>
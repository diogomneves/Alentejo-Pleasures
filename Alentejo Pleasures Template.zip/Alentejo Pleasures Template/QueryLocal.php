<?php
/**
 * Created by PhpStorm.
 * User: Diogo
 * Date: 03/01/2019
 * Time: 17:40
 */

class QueryLocal
{

    public $name, $address, $image, $description, $location, $schedule, $county_id, $dbConnect;

    /**
     * Hoteis constructor.
     * @param $name
     * @param $address
     * @param $image
     * @param $description
     * @param $location
     * @param $schedule
     * @param $county_id
     * @param $dbConnect
     */
    public function __construct($name, $address, $image, $description, $location, $schedule, $county_id)
    {
        $this->name = $name;
        $this->adress = $address;
        $this->image = $image;
        $this->description = $description;
        $this->location = $location;
        $this->schedule = $schedule;
        $this->county_id = $county_id;
        $this->dbConnect = $this->connection();
    }


    public function connection(){


        $servername = "localhost";
        $username = "twdm";
        $password = "password";
        $dbname = "alentejopleasures";

        // Create connection
        $dbConnect = new mysqli($servername, $username, $password, $dbname);
        $dbConnect-> set_charset('utf8mb4');

        // Check connection
        if ($dbConnect->connect_error) {
            die("Connection failed: " . $dbConnect->connect_error);
        }else{
            return $dbConnect;
        }
    }

    public function endConnection(){

        $this->dbConnect->close();
    }


    public function queryHotels(){

       // $sql = "SELECT local.name, local.image, local.address FROM category , local_route , local WHERE category.category_id = local_route.category_id AND local_route.local_id = local.local_id ORDER BY RAND()LIMIT 5";
       $sql = "SELECT local.name, local.image, local.description FROM local , local_route , category WHERE local.local_id = local_route.local_id  AND local_route.category_id = local_route.category_id AND category.category_id = 2 AND local.local_id <=5";
        $result = $this->dbConnect->query($sql);
        $this->endConnection();

        return $result;
    }


    public function queryAllDistrict()
    {
        $sql = "SELECT * FROM district";
        $result = $this->dbConnect->query($sql);
        $this->dbConnect;
        return $result;
    }

    public function queryCountyName($conn,$id)
    {
        $sql = "SELECT * FROM county WHERE district_id='$id'";
        $result = $conn->query($sql);
        endConnDB($conn);
        return $result;
    }


    public function queryAllLocal() {

    $sql = "SELECT name FROM local WHERE name='$this->name'";
    $result = $this->dbConnect->query($sql);
    $this->endConnection();

    return $result;
    }

    public function queryMonumentName(){

        $sql = "SELECT name FROM local WHERE name='$this->name'";
        $result = $this->dbConnect->query($sql);
        $this->endConnection();

        return $result;
    }



}
<!doctype html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <title>Alentejo Pleasures</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <link rel="stylesheet" href="fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <!-- Theme Style -->
    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="css/registerLoginStyle.css">
</head>

<?php

include_once "QuerysUser.php";

// define variables and set to empty values
$nameErr = $passwordErr = "";
$name = $password = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["name"])) {
        $nameErr = "O nome é obrigatório!";
    } else {
        $name = test_input($_POST["name"]);
        // check if name only contains letters
        if (!preg_match("/^[a-zA-Z0-9]*$/", $name)) {
            $nameErr = "O nome de utilizador só pode ter letras e algarismos!";
        }
    }

    if (empty($_POST["password"])) {
        $passwordErr = "A senha é obrigatória!";
    } else {
        $password = test_input($_POST["password"]);
    }
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>


<?php
if (isset($_POST['submit']) && $nameErr=="" && $passwordErr=="")
{
    $nuser = new QuerysUser($name,$password,"");
    $result = $nuser->login();
    if ($result->num_rows == 1)
    {
        $nuser->create_session();
        header("Location: index.php");
        // echo "Utilizador ",$name," fez login com sucesso e a sessão foi criada!";
    }
    else
        echo "Erro no login:",$nuser->conn->error;
}

?>


<body>

<div class="wrap">

    <div class="block-45">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <ul class="block-45-list">
                    </ul>


                </div>
                <div class="col-md-6 text-md-right">
                    <ul class="block-45-icons">

                        <li><a href="login.php">Login</a></li>
                        <li><a href="registo.php">Registar</a></li>

                    </ul>
                </div>

            </div>
        </div>
    </div>

    <header role="banner">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand absolute" href="#">Alentejo Pleasures</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample05" aria-controls="navbarsExample05" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse navbar-light" id="navbarsExample05">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="monumentos.php">Monumentos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="rotas.php">Rotas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="hoteis.php">Hóteis</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="experiencias.php">Experiências</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="" id="dropdown05" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Sobre Nós</a>
                            <div class="dropdown-menu" aria-labelledby="dropdown05">
                                <a class="dropdown-item" href="colaboradores.php">Colaboradores</a>
                                <a class="dropdown-item" href="contactos.php">Contactos</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- END header -->






        <body class="loginBody"style="background-image: url(images/Login.jpg);">
    <div class="loginBox">
        <h2>Alentejo Pleasures</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="text" name="name" placeholder="Nome" required>
            <input type="password" name="password" placeholder="Senha" required>
            <input type="submit" name="submit" value="Sign In">
            Não tem conta?&nbsp&nbsp<a id="registerLine" href="registo.php">Registe-se</a>
        </form>
    </div>
        </body>








</body>
</html>
<?php
/**
 * Created by PhpStorm.
 * User: ESEB
 * Date: 15-11-2018
 * Time: 12:22
 */

class QuerysUser
{
    public $name, $password, $email, $conn;

    public const SESSION_TIME = 2000;

    public function __construct($name, $password, $email)
    {
        $this->name = $name;
        $this->password = $password;
        $this->email = $email;
        $this->conn = $this->connDB();
    }

    public function connDB ()
    {
        $servername = "localhost";
        $username = "twdm";
        $password = "password";
        $dbname = "alentejopleasures";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        else {
            // echo "<br>","Ligado","<br>";
            return $conn;
        }
    }

    public function endConnDB ()
    {
        $this->conn->close();
    }

    public function register()
    {
        $sql = "INSERT INTO user(name, password, email) VALUES ('$this->name', '$this->password', '$this->email')";
        $result = $this->conn->query($sql);
        $this->endConnDB();
        return $result;
    }

    public function login()
    {
        $sql = "SELECT name,password FROM user WHERE name='$this->name' AND password='$this->password'";
        $result = $this->conn->query($sql);
        $this->endConnDB();
        return $result;
    }

    public function create_session()
    {
        session_start();
        $_SESSION['username']=$this->name;
        $_SESSION['start']=time();
        $_SESSION['expire']=$_SESSION['start'] + self::SESSION_TIME;


    }

    public function check_session()
    {
        if(empty($_SESSION))
            return false;
        elseif (time() > $_SESSION['expire'])
        {
            session_destroy();
            return false;
        }
        else
            return true;
    }

    public function close_session()
    {
        if(empty($_SESSION))
            return false;
        else
        {
            session_destroy();
            return true;
        }
    }
}



<!doctype html>
<html lang="pt">
<head>
    <title>Alentejo Pleasures</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <link rel="stylesheet" href="fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <!-- Theme Style -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="block-45">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <ul class="block-45-list">
                    <img src="images/person.png" alt="Avatar" style="width:40px; border-radius: 50%; align="right";>

                    <!-- VER SE ESTÀ LOGADO -->
                    <?php

                    session_start();

                    echo $_SESSION['username'];

                    ?>
                </ul>


            </div>
            <div class="col-md-6 text-md-right">
                <ul class="block-45-icons">

                    <li><a href="login.php">Login</a></li>
                    <li><a href="registo.php">Registar</a></li>

                </ul>
            </div>

        </div>
    </div>
</div>


    <header role="banner">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand absolute" href=index.php">Alentejo Pleasures</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample05" aria-controls="navbarsExample05" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse navbar-light" id="navbarsExample05">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="monumentos.php">Monumentos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="rotas.php">Rotas</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="hoteis.html">Hóteis</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="experiencias.php">Experiências</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="" id="dropdown05" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Sobre Nós</a>
                            <div class="dropdown-menu" aria-labelledby="dropdown05">
                                <a class="dropdown-item" href="colaboradores.php">Colaboradores</a>
                                <a class="dropdown-item" href="contactos.php">Contactos</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- END header -->

    <section class="site-hero overlay" data-stellar-background-ratio="0.5" style="background-image: url(images/hoteis2.jpg);">
        <div class="container">
            <div class="row align-items-center justify-content-center site-hero-inner">
                <div class="col-md-8 text-center">

                    <div class="mb-5 element-animate">
                        <div class="block-17">

                            <h1 class="heading mb-4">Hóteis</h1>
                            <span class="lead">ESCREVER ALGO</span>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- END section -->





    <section class="site-section bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="block-36">
                        <h3 class="block-36-heading">Pesquisar por:</h3>
                        <ul>
                            <form>

                                <li class="active"><a>Distrito:</a></li>
                                <select id="id_ctype" name="id_ctype">
                                    <option value="0">None</option>
                                </select>
                                <li class="active"><a>Concelho:</a></li>
                                <select id="id_c" name="id_c">
                                </select>
                                <br><br>
                                <input id="add" type="button" value="Filtrar">
                            </form>



                        </ul>
                    </div>
                </div>
                <div class="col-md-8 pl-md-5">

                    <div class="block-44 d-flex mb-3">

                        <div class="block-44-text">
                            <div class="block-44-icons">

                              <!--  <form>
                                <table id="table_hotel" class="tg" style="border-collapse:collapse;border-spacing:2px;">
                                    <tr>
                                        <th id="nome" name="nome"></th>
                                    </tr>
                                    <tr>
                                        <td id="imagem" name="imagem"></td>
                                    <tr></tr>
                                        <td id="descricao" name="descricao"></td>
                                    </tr>

                                </table>
                                </form> -->


                                <?php

                                include_once "QueryLocal.php";

                                $nuser = new QueryLocal("", "", "", "", "", "", "");
                                $result = $nuser->queryHotels();

                                echo "<br>";

                                if ($result->num_rows > 0) {
                                    echo "<table style='align=center; border=4; cellspacing=10; cellpadding=4;'>";
                                    echo "<tr></tr>";
                                    "</div>";

                                    while ($row = $result->fetch_assoc()) {

                                        echo "<tr>",
                                        "<td style='text-align: center;  padding-bottom: 50px; padding-top: 50px'>",$row['name'],"</td>",
                                        "</tr>",

                                            "<td ><img align='center' onclick='image' id='image' src=" . $row['image']," height='250' width='350'></td>",
                                        "<td  onclick='image' style='padding-left: 50px; padding-bottom: 50px'; align='center';>", $row['description'],"</td>",
                                        "</tr>";
                                    }
                                    echo  "</table>";

                                }
                                ?>


                                <script>
                                    // onclick event is assigned to the #button element.
                                    document.getElementById("image").onclick = function() {
                                        window.location.href = "index.php";
                                    };
                                </script>

                            </div>
                        </div>
                    </div>



                    <!--<div class="site-section">
                        <div class="section-heading">
                            <h2 class="heading">More Sermons</h2>
                        </div>

                        <div class="block-44 d-flex mb-3">
                            <div class="block-44-image"><img src="images/image_tall_1.jpg" alt="Image placeholder"></div>
                            <div class="block-44-text">
                                <h3 class="block-44-heading"><a href="sermon-single.html">Rebuilding The Walls</a></h3>
                                <div class="block-44-meta">Posted on June 28, 2018, Pastor Gregg Smith</div>
                                <div class="block-44-icons">
                                    <a href="#" class=""><span class="fa fa-video-camera"></span></a>
                                    <a href="#" class=""><span class="fa fa-headphones"></span></a>
                                    <a href="#" class=""><span class="fa fa-cloud-download"></span></a>
                                    <a href="#" class=""><span class="fa fa-book"></span></a>
                                </div>
                            </div>
                        </div>

                        <div class="block-44 d-flex mb-3">
                            <div class="block-44-image"><img src="images/image_tall_2.jpg" alt="Image placeholder"></div>
                            <div class="block-44-text">
                                <h3 class="block-44-heading"><a href="sermon-single.html">Jonah's Message To Neniveh</a></h3>
                                <div class="block-44-meta">June 28, 2018, Pastor Gregg Smith</div>
                                <div class="block-44-icons">
                                    <a href="#" class=""><span class="fa fa-video-camera"></span></a>
                                    <a href="#" class=""><span class="fa fa-headphones"></span></a>
                                    <a href="#" class=""><span class="fa fa-cloud-download"></span></a>
                                    <a href="#" class=""><span class="fa fa-book"></span></a>
                                </div>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div>

            <div class="row mt-5">
                <div class="col-md-12 pt-5">
                    <ul class="pagination custom-pagination">
                        <li class="page-item prev"><a class="page-link" href="#"><i class="ion-ios-arrow-back"></i></a></li>
                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item next"><a class="page-link" href="#"><i class="ion-ios-arrow-forward"></i></a></li>
                    </ul>


                </div>
            </div>



        </div>
    </section>



    <footer class="site-footer">
        <div class="container">
            <div class="row mb-5">
                <div class="col-md-6 col-lg-3 mb-5 mb-lg-0">
                    <h3 class="heading">Contactos</h3>
                    <div class="block-23 float-md-right">
                        <ul>
                            <li><span class="icon ion-android-pin"></span><span class="text">Rua Coronel Manuel Emidio Lt.4 - Évora</span></li>
                            <li><a href="#"><span class="icon ion-ios-telephone"></span><span class="text">266 754 890</span></a></li>
                            <li><a href="#"><span class="icon ion-android-mail"></span><span class="text">alentejopleasures@gmail.com</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row pt-5">
                <div class="col-md-12 text-center copyright">

                    <p class="float-md-left"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Alentejo Pleasures
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                    <p class="float-md-right">
                        <a href="#" class="fa fa-facebook p-2"></a>
                        <a href="#" class="fa fa-twitter p-2"></a>
                        <a href="#" class="fa fa-linkedin p-2"></a>
                        <a href="#" class="fa fa-instagram p-2"></a>

                    </p>
                </div>
            </div>
        </div>
    </footer>
    <!-- END footer -->

</div>

<!-- loader -->
<div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#f4b214"/></svg></div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/jquery-migrate-3.0.0.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>

<script src="js/jquery.magnific-popup.min.js"></script>

<script src="js/main.js"></script>


<script>
    $( window ).ready(function($){
        $.post(
            "php/getDistrict.php",
            {},
            function(data, status){
                if (status == "success")
                {
                    var objData = JSON.parse(data);
                    for (item in objData)
                        $( "select#id_ctype" ).append("<option value='" + objData[item].district_id + "'>" + objData[item].name + "</option>");
                }
            }
        )
    });

    $( "select#id_ctype" ).change(function () {
        var id = "";
        $( "select#id_ctype option:selected" ).each(function() {
            id = $( "select#id_ctype" ).val();
            <!-- limpar lista -->
            $( "select#id_c" ).html("");
        });

        $.post(
            "php/getCounty.php",
            {
                id: id
            },
            function(data, status){
                if (status == "success")
                {
                    var objData = JSON.parse(data);
                    for (item in objData)
                        $( "select#id_c" ).append("<option value='" + objData[item].county_id + "'>" + objData[item].name + "</option>");
                }
            }
        )
    });

    $( "input#add" ).click(function () {
        $ ( "div#list" ).append("<p>" + $( "select#id_ctype option:selected" ).text() + " - " + $( "select#id_c option:selected" ).text() + "</p>");
    });

</script>

</body>
</html>



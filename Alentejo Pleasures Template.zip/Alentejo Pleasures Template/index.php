<!doctype html>
<html lang="pt" xmlns:border-radius="http://www.w3.org/1999/xhtml">
<head>
    <title>Alentejo Pleasures</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <link rel="stylesheet" href="fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/magnific-popup.css">



    <!-- Theme Style -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="wrap">

    <div class="block-45">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <ul class="block-45-list">
                        <li><a href="login.php">Login</a></li>
                        <li><a href="registo.php">Registar</a></li>
                        <img src="images/person.png" alt="Avatar" style="width:40px; border-radius: 50%; align="right";>

                        <!-- VER SE ESTÀ LOGADO -->
                        <?php

                        session_start();

                        echo "Bem-vindo " . $_SESSION['username'];


                        ?>








                    </ul>

                    <button style="text-align: right" type="button">Click Me!</button>
                </div>

            </div>
        </div>
    </div>

    <header role="banner">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand absolute" href="#">Alentejo Pleasures</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample05" aria-controls="navbarsExample05" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse navbar-light" id="navbarsExample05">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="monumentos.php">Monumentos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="rotas.php">Rotas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="hoteis.php">Hóteis</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="experiencias.php">Experiências</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="" id="dropdown05" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Sobre Nós</a>
                            <div class="dropdown-menu" aria-labelledby="dropdown05">
                                <a class="dropdown-item" href="colaboradores.php">Colaboradores</a>
                                <a class="dropdown-item" href="contactos.php">Contactos</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- END header -->

    <section class="site-hero overlay" data-stellar-background-ratio="0.5" style="background-image: url(images/Alentejo.jpg);">
        <div class="container">
            <div class="row align-items-center justify-content-center site-hero-inner">
                <div class="col-md-8 text-center">

                    <div class="mb-5 element-animate">
                        <div class="block-17">
                            <h1 class="heading mb-4">Visite o alentejo de lés-a-lés.</h1>
                            <p><!--a href="#" class="btn btn-primary-white py-3 px-5">Sobre Nós</a--> <a href="#" class="text-white ml-4"> <!--span class="ion-ios-location mr-2" style="color: #f37021"></span--></a></p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- END section -->

    <section class="site-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 order-md-2">
                    <div class="block-16">
                        <figure>
                            <iframe src="https://player.vimeo.com/video/19466446" width="640" height="360" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
                            <p><a href="https://vimeo.com/19466446">The Alentejo</a> from <a href="https://vimeo.com/barrocalfilms">BarrocalFilms</a> on <a href="https://vimeo.com">Vimeo</a>.</p>
                        </figure>
                    </div>
                </div>
                <div class="col-md-6 order-md-1">

                    <div class="block-15">
                        <div class="heading">
                            <h2>Bem-Vindo ao Alentejo Pleasures</h2>
                        </div>
                        <div class="text mb-5">
                            <p class="mb-4">Viaje na imensidão do nosso grande alentejo na nossa companhia, Alentejo Pleasures dá-lhe a oportunidade de conhecer todos os quatro cantos do alentejo.</p>
                            <p style="font-size:14px;"><i>"A percorrer o Alentejo, nem me fatigo, nem cabeceio de sono, nem me torno hipocondríaco. Cruzo a região de lés a lés, num deslumbramento de revelação."</i><br> Miguel Torga</p>
                        </div>

                    </div>

                </div>

            </div>

        </div>
    </section>
    <!-- END section -->


    <div class="block-13">
        <div class="nonloop-block-13 owl-carousel">
            <div class="item">
                <div class="block-20">
                    <figure>
                        <a href="monumentos.php"><img src="images/Monumento.jpg" alt="Image placeholder" class="img-fluid"></a>
                    </figure>
                    <div class="text text-center">
                        <h3 class="heading"><a href="monumentos.php">Monumentos</a></h3>
                    </div>
                </div>
            </div>

            <div class="item">
                <div class="block-20">
                    <figure>
                        <a href="rotas.php"><img src="images/Rota.jpg" alt="Image placeholder" class="img-fluid"></a>
                    </figure>
                    <div class="text text-center">
                        <h3 class="heading"><a href="rotas.php">Rotas</a></h3>
                    </div>
                </div>
            </div>

            <div class="item">
                <div class="block-20">
                    <figure>
                        <a href="#"><img src="images/Vinho.jpg" alt="Image placeholder" class="img-fluid"></a>
                    </figure>
                    <div class="text text-center">
                        <h3 class="heading"><a href="#">Vinhos</a></h3>
                    </div>
                </div>
            </div>

            <div class="item">
                <div class="block-20">
                    <figure>
                        <a href="#"><img src="images/Praia.jpg" alt="Image placeholder" class="img-fluid"></a>
                    </figure>
                    <div class="text text-center">
                        <h3 class="heading"><a href="#">Praias</a></h3>
                    </div>
                </div>
            </div>

            <div class="item">
                <div class="block-20">
                    <figure>
                        <a href="hoteis.php"><img src="images/Hotel.jpg" alt="Image placeholder" class="img-fluid"></a>
                    </figure>
                    <div class="text text-center">
                        <h3 class="heading"><a href="hoteis.php">Hotéis</a></h3>
                    </div>
                </div>
            </div>

            <div class="item">
                <div class="block-20">
                    <figure>
                        <a href="experiencias.php"><img src="images/Balão.jpg" alt="Image placeholder" class="img-fluid"></a>
                    </figure>
                    <div class="text text-center">
                        <h3 class="heading"><a href="experiencias.php">Experiências</a></h3>
                    </div>
                </div>
            </div>

        </div>
    </div>
    </section>

    <div class="site-section bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading mb-5">
                        <h2 class="heading">Colaboradores</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-lg-4 mb-5">

                    <div class="block-33">
                        <div class="vcard d-flex">
                            <div class="image align-self-center ml-auto order-2 ml-3"><img src="images/DiogoGuerreiro.jpg" alt="Person here"></div>
                            <div class="name-text align-self-center ml-auto order-1 text-right">
                                <h2 class="heading">Diogo Guerreiro</h2>
                                <span class="meta">Castro Verde</span>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-md-6 col-lg-4 mb-5">
                    <div class="block-33">
                        <div class="vcard d-flex">
                            <div class="image align-self-center ml-auto order-2 ml-3"><img src="images/DiogoNeves.jpg" alt="Person here"></div>
                            <div class="name-text align-self-center ml-auto order-1 text-right">
                                <h2 class="heading">Diogo Neves</h2>
                                <span class="meta">Castro Verde</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-5">

                    <div class="block-33">
                        <div class="vcard d-flex">
                            <div class="image align-self-center ml-auto order-2 ml-3"><img src="images/ricardo.jpg" alt="Person here"></div>
                            <div class="name-text align-self-center ml-auto order-1 text-right">
                                <h2 class="heading">Ricardo Mestre</h2>
                                <span class="meta">Cabeça Gorda</span>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>





    <footer class="site-footer">
        <div class="container">
            <div class="row mb-5">
                <div class="">
                    <h3 class="heading">Contactos</h3>
                    <div class="block-23">
                        <ul>
                            <li><span class="icon ion-android-pin"></span><span class="text">Rua Coronel Manuel Emídio Lt.4 - Évora</span></li>
                            <li><a href="#"><span class="icon ion-ios-telephone"></span><span class="text">266 754 890</span></a></li>
                            <li><a href="#"><span class="icon ion-android-mail"></span><span class="text">alentejopleasures@gmail.com</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row pt-5">
                <div class="col-md-12 text-center copyright">

                    <p class="float-md-left"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        <b>Copyright &copy;&nbsp;<script>document.write(new Date().getFullYear());</script> All Rights Reserved | Alentejo Pleasures</b>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                    <p class="float-md-right">
                        <a href="#" class="fa fa-facebook p-2"></a>
                        <a href="#" class="fa fa-twitter p-2"></a>
                        <a href="#" class="fa fa-linkedin p-2"></a>
                        <a href="#" class="fa fa-instagram p-2"></a>



                    </p>
                </div>
            </div>
        </div>
    </footer>
    <!-- END footer -->

</div>

<!-- loader -->
<div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#f4b214"/></svg></div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/jquery-migrate-3.0.0.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>

<script src="js/jquery.magnific-popup.min.js"></script>

<script src="js/main.js"></script>
</body>
</html>
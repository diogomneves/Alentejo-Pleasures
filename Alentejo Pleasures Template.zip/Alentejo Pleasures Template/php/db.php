<?php
/**
 * Created by PhpStorm.
 * User: ESEB
 * Date: 04-12-2018
 * Time: 12:09
 */

function connDB ()
{
    $servername = "localhost";
    $username = "twdm";
    $password = "password";
    $dbname = "alentejopleasures";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    $conn->set_charset('utf8mb4');

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    else {
        // echo "<br>","Ligado","<br>";
        return $conn;
    }
}

function endConnDB ($conn)
{
    $conn->close();
}

function queryAllDistrict($conn)
{
    $sql = "SELECT * FROM district";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function queryAllCounty ($conn, $id)
{
    $sql = "SELECT * FROM county WHERE district_id='$id'";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;
}

function queryAllHotel($conn){

    $sql = "SELECT local.name, local.image , local.description FROM local , local_route , category WHERE local.local_id = local_route.local_id AND local_route.category_id = 2";
    $result = $conn->query($sql);
    endConnDB($conn);
    return $result;




}
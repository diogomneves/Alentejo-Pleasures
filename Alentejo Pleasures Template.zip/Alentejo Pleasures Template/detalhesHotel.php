<!doctype html>
<html lang="pt">
<head>
    <title>Alentejo Pleasures</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <link rel="stylesheet" href="fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <!-- Theme Style -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="wrap">
    <div class="block-45">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <ul class="block-45-list">
                        <li><a href="login.html">Login</a></li>
                        <li><a href="registo.html">Registar</a></li>

                        <!-- VER SE ESTÀ LOGADO -->
                        <?php

                        session_start();

                        echo $_SESSION['username'];


                        ?>

                    </ul>
                </div>
                <div class="col-md-6 text-md-right">
                    <ul class="block-45-icons">
                        <li><a href="3"><span class="fa fa-facebook fa-lg"></span></a></li>
                        <li><a href="3"><span class="fa fa-twitter fa-lg"></span></a></li>
                        <li><a href="3"><span class="fa fa-linkedin fa-lg"></span></a></li>
                        <li><a href="3"><span class="fa fa-instagram fa-lg"></span></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <header role="banner">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand absolute" href=index.php">Alentejo Pleasures</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample05" aria-controls="navbarsExample05" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse navbar-light" id="navbarsExample05">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="monumentos.php">Monumentos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="rotas.php">Rotas</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="hoteis.html">Hóteis</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="experiencias.php">Experiências</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="" id="dropdown05" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Sobre Nós</a>
                            <div class="dropdown-menu" aria-labelledby="dropdown05">
                                <a class="dropdown-item" href="colaboradores.php">Colaboradores</a>
                                <a class="dropdown-item" href="contactos.php">Contactos</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- END header -->

    <section class="site-hero overlay" data-stellar-background-ratio="0.5" style="background-image: url(images/hoteis2.jpg);">
        <div class="container">
            <div class="row align-items-center justify-content-center site-hero-inner">
                <div class="col-md-8 text-center">

                    <div class="mb-5 element-animate">
                        <div class="block-17">

                            <h1 class="heading mb-4">Hóteis</h1>
                            <span class="lead">ESCREVER ALGO</span>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- END section -->

    <section class="site-section bg-light">
                <div class="col-md-8 pl-md-5">

                    <div class="block-44 d-flex mb-3">

                        <div class="block-44-text">
                            <div class="block-44-icons">
                                <?php
                                include_once "QueryLocal.php";

                                $nuser = new QueryLocal("", "", "", "", "", "", "");
                                $result = $nuser->queryHotels();

                                echo "<br>";

                                if ($result->num_rows > 0) {
                                    echo "<table style='border=0; align=center'>";
                                    echo "<tr></tr>";
                                    "</div>";

                                    while ($row = $result->fetch_assoc()) {

                                        echo "<tr>",
                                        "<td style='text-align: center'>",$row['name'],"</td>",
                                        "</tr>",

                                            "<td ><img align='center' onclick='image' id='image' src=" . $row['image']," height='250' width='350'></td>",
                                        "<td >", $row['description'],"</td>",
                                        "</tr>";
                                    }
                                    echo  "</table>";

                                }
                                ?>


                                <script>
                                    // onclick event is assigned to the #button element.
                                    document.getElementById("image").onclick = function() {
                                        window.location.href = "index.php";
                                    };
                                </script>

                            </div>
                        </div>
                    </div>